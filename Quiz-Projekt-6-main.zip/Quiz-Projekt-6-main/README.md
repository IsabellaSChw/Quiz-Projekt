```markdown
Erklärung des Codes unter folgendem Link: 
